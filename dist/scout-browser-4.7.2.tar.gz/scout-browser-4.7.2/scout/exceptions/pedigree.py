class PedigreeError(Exception):
    pass