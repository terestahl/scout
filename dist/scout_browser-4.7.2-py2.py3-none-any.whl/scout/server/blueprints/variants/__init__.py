# -*- coding: utf-8 -*-
from .views import variants_bp
