from __future__ import unicode_literals

STATUS = ("prioritized", "inactive", "active", "solved", "archived")
