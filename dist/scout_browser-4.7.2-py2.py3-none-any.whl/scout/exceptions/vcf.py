class VcfError(Exception):
    pass